package com.bibah.payjam.activity;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import androidx.appcompat.app.AppCompatActivity;

import com.bibah.payjam.R;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main); // Pastikan file layout Anda disimpan di res/layout/activity_main.xml

        ImageView ptImageView = findViewById(R.id.pt);
        ImageView jmlgajiImageView = findViewById(R.id.jmlgaji);
        ImageView userImageView = findViewById(R.id.user);
        ImageView logohomeImageView = findViewById(R.id.logohome);
        ImageView logodetailImageView = findViewById(R.id.logodetail);

        ptImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Tambahkan tindakan yang sesuai saat gambar pt diklik
            }
        });

        jmlgajiImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Tambahkan tindakan yang sesuai saat gambar jmlgaji diklik
            }
        });

        userImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Tambahkan tindakan yang sesuai saat gambar user diklik
            }
        });

        logohomeImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Tambahkan tindakan yang sesuai saat gambar logohome diklik
            }
        });

        logodetailImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Tambahkan tindakan yang sesuai saat gambar logohome diklik
            }
        });
    }
}