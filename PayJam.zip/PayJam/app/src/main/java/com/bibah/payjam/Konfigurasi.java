package com.bibah.payjam;

public class Konfigurasi {
    //  Login Configuration
    public static final String URL_LOGIN    = "https://beeodata-api.000webhostapp.com/gaji/login.php";
    public static final String KEY_NIK      = "nik";
    public static final String KEY_PASS     = "password";

    //  Non useable function
    public static final String TAG_JSON_ARRAY="result";
    public static final String TAG_NAMA     = "nama";

}
