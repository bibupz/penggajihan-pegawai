package com.bibah.payjam.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.bibah.payjam.R;

public class DetailsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);
    }
}