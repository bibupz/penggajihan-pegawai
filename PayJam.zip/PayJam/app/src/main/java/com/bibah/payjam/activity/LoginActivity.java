package com.bibah.payjam.activity;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.bibah.payjam.Konfigurasi;
import com.bibah.payjam.LoadingAlert;
import com.bibah.payjam.R;
import com.bibah.payjam.RequestHandler;

import java.util.HashMap;

public class LoginActivity extends AppCompatActivity {

    private EditText nik, password;
    private Button btnSubmit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        nik = findViewById(R.id.nik);
        password = findViewById(R.id.pw);
        btnSubmit = findViewById(R.id.btn_submit);
        btnSubmit.setOnClickListener(new View.OnClickListener() { @Override
            public void onClick(View view) {
            class Login extends AsyncTask<Void, Void, String> {
                LoadingAlert dialogProgres = new LoadingAlert();

                @Override
                protected void onPreExecute() {
                    super.onPreExecute();
                    dialogProgres.show(getSupportFragmentManager(), "test");
                }


                @Override
                protected void onPostExecute(String s) {
                    super.onPostExecute(s);
                    dialogProgres.dismiss();

                    if (s.equals("Login Berhasil")){
                        Toast.makeText(LoginActivity.this, "Login Berhasil", Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                        HashMap<String, String> params = new HashMap<>();
                        intent.putExtra("nik", String.valueOf(nik.getText()));
                        intent.putExtra("password", String.valueOf(password.getText()));
                        startActivity(intent);
                        finish();
                    }
                    else if (s.equals("Username atau Password Salah")){
                        Toast.makeText(LoginActivity.this, "Username atau Password Salah", Toast.LENGTH_SHORT).show();
                        // LoginFailedAlert FailedProgress = new LoginFailedAlert();
                        // FailedProgress.show(getSupportFragmentManager(), "test");
                    }
                    else {
                        Toast.makeText(LoginActivity.this, s, Toast.LENGTH_SHORT).show();
                        // NoConnectionAlert NoConnectionProgress = new NoConnectionAlert();
                        // NoConnectionProgress.show(getSupportFragmentManager(), "test");
                    }
                }

                @Override
                protected String doInBackground(Void... voids) {
                    HashMap<String, String> params = new HashMap<>();
                    params.put(Konfigurasi.KEY_NIK, String.valueOf(nik.getText()));
                    params.put(Konfigurasi.KEY_PASS, String.valueOf(password.getText()));

                    RequestHandler rh = new RequestHandler();
                    String res = rh.sendPostRequest(Konfigurasi.URL_LOGIN, params);
                    return res;
                }
            }

            Login log = new Login();
            log.execute();
            }
        });
    }
}